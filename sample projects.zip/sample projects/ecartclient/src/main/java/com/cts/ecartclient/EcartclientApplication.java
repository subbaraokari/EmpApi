package com.cts.ecartclient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EcartclientApplication {

    public static void main(String[] args) {
        SpringApplication.run(EcartclientApplication.class, args);
    }

}
