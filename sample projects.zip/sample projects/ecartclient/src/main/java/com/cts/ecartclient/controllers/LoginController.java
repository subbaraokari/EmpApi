package com.cts.ecartclient.controllers;

import com.cts.ecartclient.model.ApplicationUser;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

@Controller
public class LoginController {
    @GetMapping("/")
    public String showHome(){
        return "index";
    }
    @PostMapping("/login")
    public String processForm(@RequestParam("username") String userName,@RequestParam("password") String password){
        RestTemplate rt=new RestTemplate();
        ApplicationUser user=new ApplicationUser();
        user.setUserName(userName);
        user.setPassword(password);
        ResponseEntity<String> response=rt.postForEntity("http://desktop-tdtr5dk:8090/api/auth/login",user,String.class);
        if(response.getStatusCode().value()==200){
            return "products";
        }
        return "index";

    }
}
