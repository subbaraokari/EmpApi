package com.cts.authenticationservice.services;

import com.cts.authenticationservice.entities.ApplicationUser;
import com.cts.authenticationservice.repository.UserRepository;
import org.springframework.stereotype.Service;

@Service
public class AuthServiceImpl implements AuthService{
    private UserRepository userRepository;

    public AuthServiceImpl(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public boolean validate(String userName, String password) {
        boolean b=false;
        ApplicationUser user=userRepository.findByUserNameAndPassword(userName,password);
        if(user!=null)
            b=true;
        return b;
    }
}
