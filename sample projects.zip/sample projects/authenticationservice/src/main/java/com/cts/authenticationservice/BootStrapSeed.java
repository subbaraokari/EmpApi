package com.cts.authenticationservice;

import com.cts.authenticationservice.entities.ApplicationUser;
import com.cts.authenticationservice.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class BootStrapSeed implements CommandLineRunner {
    private UserRepository repository;

    public BootStrapSeed(UserRepository repository) {
        this.repository = repository;
    }

    @Override
    public void run(String... args) throws Exception {
        ApplicationUser user1=new ApplicationUser();
        user1.setUserName("suresh");
        user1.setPassword("suresh@123");
        ApplicationUser user2=new ApplicationUser();
        user2.setUserName("ramesh");
        user2.setPassword("ramesh@123");
        repository.save(user1);
        repository.save(user2);

    }
}

