package com.cts.authenticationservice.services;

public interface AuthService {
    boolean validate(String userName,String password);
}
